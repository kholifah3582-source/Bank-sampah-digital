const express = require('express');
const router = express.Router();
const { auth, requireRole } = require('./middleware');
const { Deposit, User } = require('../models');

router.get('/deposits', auth, requireRole('admin'), async (req,res) => {
  const deps = await Deposit.findAll({ order: [['createdAt','DESC']]});
  res.json(deps);
});

router.post('/deposits/:id/verify', auth, requireRole('admin'), async (req,res) => {
  const id = req.params.id;
  const dep = await Deposit.findByPk(id);
  if (!dep) return res.status(404).json({ error: 'Setoran tidak ditemukan' });
  if (dep.status === 'verified') return res.status(400).json({ error: 'Sudah terverifikasi' });

  dep.status = 'verified';
  dep.verifiedBy = req.user.id;
  await dep.save();

  const user = await User.findByPk(dep.userId);
  if (user) {
    user.balance = (user.balance || 0) + (dep.totalValue || 0);
    await user.save();
  }

  res.json({ ok: true, deposit: dep });
});

router.post('/deposits/:id/reject', auth, requireRole('admin'), async (req,res) => {
  const id = req.params.id;
  const dep = await Deposit.findByPk(id);
  if (!dep) return res.status(404).json({ error: 'Setoran tidak ditemukan' });
  dep.status = 'rejected';
  await dep.save();
  res.json({ ok:true });
});

module.exports = router;
