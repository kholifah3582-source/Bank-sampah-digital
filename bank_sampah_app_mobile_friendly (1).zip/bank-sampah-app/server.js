require('dotenv').config();
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const { sequelize, User, Bank, Price } = require('./models');

const authRoutes = require('./routes/auth');
const banksRoutes = require('./routes/banks');
const depositRoutes = require('./routes/deposits');
const adminRoutes = require('./routes/admin');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/', express.static(path.join(__dirname, 'public')));

const upload = multer({ dest: path.join(__dirname, 'uploads/') });
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use('/api/auth', authRoutes);
app.use('/api/banks', banksRoutes);
app.use('/api/deposits', upload.single('photo'), depositRoutes);
app.use('/api/admin', adminRoutes);

const PORT = process.env.PORT || 4000;
(async () => {
  await sequelize.sync();
  console.log('DB synced');
  const admin = await User.findOne({ where: { email: 'admin@bank.com' }});
  if (!admin) {
    const bcrypt = require('bcrypt');
    const pwd = await bcrypt.hash('admin123', 10);
    await User.create({ name: 'Admin', email: 'admin@bank.com', passwordHash: pwd, role: 'admin', balance: 0 });
    console.log('Seeded admin user -> admin@bank.com / admin123');
  }
  const b = await require('./models').Bank.findByPk('BS-01');
  if (!b) {
    await require('./models').Bank.create({ id: 'BS-01', name: 'Bank Sampah RW 05', address: 'Jl. Contoh No.1', contact: '08123456789' });
    await require('./models').Bank.create({ id: 'BS-02', name: 'Bank Sampah Kel. Maju', address: 'Jl. Contoh 2', contact: '08123456780' });
    await require('./models').Price.create({ materialType: 'Plastik', pricePerKg: 3000 });
    await require('./models').Price.create({ materialType: 'Kertas', pricePerKg: 2000 });
    await require('./models').Price.create({ materialType: 'Logam', pricePerKg: 10000 });
    console.log('Seeded banks & prices');
  }

  app.listen(PORT, () => console.log(`Server listening on http://localhost:${PORT}`));
})();
