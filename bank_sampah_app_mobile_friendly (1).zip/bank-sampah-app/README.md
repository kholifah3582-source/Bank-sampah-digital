Bank Sampah Digital - Starter

Cara menjalankan:
1. Pastikan Node.js terinstall.
2. unzip project, masuk ke folder.
3. cp .env.example .env   (edit .env jika perlu)
4. npm install
5. npm start
6. Buka http://localhost:4000

Admin seed: admin@bank.com / admin123
