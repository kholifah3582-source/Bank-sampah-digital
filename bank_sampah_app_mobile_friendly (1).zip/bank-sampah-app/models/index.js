const sequelize = require('../config/database');
const User = require('./user');
const Bank = require('./bank');
const Price = require('./price');
const Deposit = require('./deposit');

const models = {
  User: User.initModel(sequelize),
  Bank: Bank.initModel(sequelize),
  Price: Price.initModel(sequelize),
  Deposit: Deposit.initModel(sequelize)
};

models.User.hasMany(models.Deposit, { foreignKey: 'userId' });
models.Deposit.belongsTo(models.User, { foreignKey: 'userId' });

models.Bank.hasMany(models.Deposit, { foreignKey: 'bankId' });
models.Deposit.belongsTo(models.Bank, { foreignKey: 'bankId' });

module.exports = { sequelize, ...models };
