# ♻️ Bank Sampah Digital

**Bank Sampah Digital** adalah platform berbasis web untuk mendukung pengelolaan sampah secara modern, terintegrasi, dan menguntungkan bagi masyarakat.  
Dibangun menggunakan **Node.js + Express + SQLite**, proyek ini memungkinkan pengguna menabung sampah secara digital, melihat saldo, dan mengelola data melalui dashboard admin.

---

## 🚀 Fitur Utama

### 👥 Pengguna
- Login dan registrasi akun  
- Setor sampah (pilih jenis, berat, nilai otomatis dihitung)  
- Melihat riwayat transaksi dan total saldo  

### 🧾 Admin
- Login sebagai petugas bank sampah  
- Melihat semua data setoran pengguna  
- Verifikasi, edit, atau hapus transaksi  

---

## 🛠️ Teknologi yang Digunakan
- **Backend:** Node.js + Express  
- **Database:** SQLite  
- **Template Engine:** EJS  
- **Frontend:** HTML, CSS, JavaScript  
- **Framework UI:** Bootstrap 5  
- **Deployment:** Render.com (Free Plan)

---

## ⚙️ Instalasi Lokal

### 1️⃣ Clone repositori
```bash
git clone https://github.com/USERNAME/bank-sampah-digital.git
cd bank-sampah-digital
```

### 2️⃣ Instal dependensi
```bash
npm install
```

### 3️⃣ Buat file `.env`
Isi file `.env` dengan:
```
PORT=4000
JWT_SECRET=rahasia_aman
```

### 4️⃣ Jalankan server
```bash
npm start
```

Website bisa diakses di:
👉 `http://localhost:4000`

---

## 🌍 Deploy ke Render

1. Masuk ke [Render.com](https://render.com)  
2. Login pakai GitHub  
3. Klik **“New +” → Web Service**  
4. Pilih repo `bank-sampah-digital`  
5. Isi:
   - **Build command:** `npm install`  
   - **Start command:** `npm start`  
6. Tunggu beberapa menit hingga status menjadi **Live**

---

## 🔐 Kredensial Demo
| Role | Email | Password |
|------|--------|-----------|
| Admin | admin@bank.com | admin123 |

---

## 💡 Tujuan Proyek
Meningkatkan kesadaran masyarakat tentang pengelolaan sampah yang berkelanjutan melalui pendekatan digital, menciptakan ekosistem ekonomi sirkular, dan mendukung Indonesia bersih sampah 🌿.

---

## 🧑‍💻 Kontributor
- **Nama:** *(Isi nama kamu di sini)*  
- **Pengembang:** ChatGPT + Node.js Team  
